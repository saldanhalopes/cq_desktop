<?php
thim_customizer()->add_panel(
	array(
		'id'       => 'nav_menus',
		'priority' => 90,
		'title'    => esc_html__( 'Menus', 'mag-wp' ),
		'icon'     => 'dashicons-menu'
	)
);
